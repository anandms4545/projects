const express=require('express');
const app=express();
const cors = require('cors');
const mongoose=require('mongoose');
const port=5000;
app.use(express.urlencoded({extended:false}));
app.use(express.json())
app.use(cors());
mongoose.connect("mongodb://127.0.0.1:27017/btsDB",{useNewurlParser:true});
const connection=mongoose.connection;
connection.once('open',()=>{
    console.log("Connection is done");
})
const UserDB=require('./src/routes/user.routes');
app.use('/user',UserDB);


const IssueDB=require('./src/routes/issue.routes')
app.use('/issue',IssueDB);
// const ImageMulter=require('./src/routes/asset.routes')
// app.use('/Multer',ImageMulter)
// const CartDB=require('./src/routes/cart.routes')
// app.use('/cart',CartDB)

app.listen(port,()=>{
    console.log("Server running at port 5000");
})