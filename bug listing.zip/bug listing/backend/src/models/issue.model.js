const mongoose=require('mongoose');
const Schema=mongoose.Schema;
var AutoIncrement=require('mongoose-sequence')(mongoose);
const IssueSchema=new Schema({
    issuenumber:{
        type:Number
    },
    issuedate:{
        type:Date,
        default:Date.now
    },

    issuetitle:{
        type:String
    },
    issuedetails:{
        type:String
    },
    issuecby:{
        type:String
    },
    priority:{
        type:String
    },
    issuestatus:{
        type:String
    }
  
}, {
    timestamps: true
});
IssueSchema.plugin(AutoIncrement,{id:"issuenumber_Seq",inc_field:'issuenumber'});
var Issue=mongoose.model('Issue',IssueSchema);
module.exports=Issue;