const express=require('express');
const router=express.Router();
const Usercontroller=require('../controllers/user.controller');
router.get('/getuser',Usercontroller.getUser)
router.post('/signup',Usercontroller.createUser);
router.post('/login',Usercontroller.login);
router.put('/update/:id',Usercontroller.updateUser);
router.delete('/delete/:id',Usercontroller.deleteUser);
module.exports=router;