const { request, response } = require('express');
const express=require('express');
const Issue=require('../models/issue.model');
module.exports.getIssuesDetail=async(request,response)=>{
    try{
        let issue=await Issue.find();
        response.status(200).send({success:true,issue});
    }
    catch(error){
        response.status(400).send({success:false,message:error.message});
    }
}
module.exports.getIssueDetail=async(request,response)=>{
    try{
        console.log("Id is ",request.params.id)
        let issue=await Issue.findOne({_id:request.params.id});
        
        response.status(200).send({success:true,issue});
    }
    catch(error){
        response.status(400).send({success:false,message:error.message});
    }
}

module.exports.getIssueDetailName=async(request,response)=>{
    try{
        console.log("Id is ",request.params.issuecby)
        let issue=await Issue.find({issuecby:request.params.issuecby });
        
        response.status(200).send({success:true,issue});
    }
    catch(error){
        response.status(400).send({success:false,message:error.message});
    }
}
module.exports.createIssue=async(request,response)=>{
    try{
        const{issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus}=request.body;
        let issue=new Issue({issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus});
        let result=await issue.save();
        response.status(200).send({success:true,result});
    } catch(error){
        response.status(400).send({success:false,message:error.message});
    }
}
module.exports.updateIssue=async(request,response)=>{
    try{
        const{issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus}=request.body;
        let issue=await Issue.findOne({_id:request.params._id});
        if(!issue){
            response.send("issue does not exist");
        }
        let result=await Issue.updateOne({_id:request.params._id},{issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus});
        response.status(200).send({success:true,product:{_id:request.params._id,issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus}})
    }
    catch(error){
        response.status(400).send({success:false,message:error.message});
    }
}
module.exports.deleteissue = async (request,response) => {
    console.log("_id =" + request.params._id)
    try{
        let result = await Issue.deleteOne({_id: request.params._id})
        response.status(200).json({sucess: true, _id:request.params._id});

    }
    catch (error) {console.log(error);}
}
