const { request } = require('express');
const express=require('express');
const crypto=require('crypto');
const jwt = require('jsonwebtoken')
const User=require('../models/user.model');
module.exports.getUser= async(request,response)=>{
    try{
        let user=await User.find();
        response.status(200).send({success:true,user});

    }catch(error){
        response.status(400).send({success:false,message:error.message});
    }
}
module.exports.createUser=async(request,response)=>{
    try{
        const{name,email,password,}=request.body;
        let user=new User({name,email,password});
        let result=await user.save();
        response.send({success:true,user});
    }
    catch(error){
        response.status(400).send({success:false,message:error.message});
    }
}
module.exports.login = async (request, response) => {
    console.log("REQUEST BODY IS" + JSON.stringify(request.body))
    const accessTokenSecret = 'God is almighty'
    try {
        let user = await User.findOne({
            "email": request.body.email
        })
        console.log("User is " + JSON.stringify(user))
        if (!user)
            throw new ErrorHandler(401,'Incorrect Password','Warning');
          //return response.status('401').json({  error: "User not found"})

        if (!user.authenticate(request.body.password)) {
            throw new ErrorHandler(401,'Incorrect Password','Warning')
          
            /* return response.status('401').send({
                 error: "Email and password don't match."
             })*/
        }
        const token = jwt.sign({
            _id : user._id,
            role : user.role,
        },accessTokenSecret)
        return response.json({
            token,
          user:{_id: user._id, name: user.name, email: user.email }
        })
    } catch (err) {
          console.log(err)
         return response.status('401').json({
             error: "Could not sign in"
      })
    }
}

module.exports.updateUser=async(request,response)=>{
    try{
        console.log("ID",request.params.id)
        const{name,email,password}=request.body;
        console.log("Password: ",request.body)
        let user=await User.findOne({_id:request.params.id});
        console.log("User is ",user)
        if(!user){
            response.send("User does not exist");
        }
        let hashed_password=user.encryptPassword(password);
        console.log("Hashed Password ",hashed_password)
        let result=await User.updateOne({_id:request.params.id},{name,email,hashed_password});
        console.log("Result is" ,result)
        response.send({success:true,user:{_id:request.params.id,result}})
        
        // console.log("Record updated");
        // console.log("REQUEST BODY IS" + JSON.stringify(request.body))
        // console.log("User is " + JSON.stringify(result))
    }
    catch(error){
        response.status(400).send({success:false,message:error.message});
    }
}

module.exports.deleteUser=async(request,response)=>{
    try{
        let result = await User.deleteOne({_id:request.params.id})
        response.status(200).send({success:true,_id:request.params.id})

    }
    catch(error){
        response.status(400).send({success:false,message:error.message})
    }
}


