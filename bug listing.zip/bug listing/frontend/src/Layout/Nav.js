import React from "react";
import './maincontent.css';
import { Link,useNavigate} from "react-router-dom";
import { useSelector ,useDispatch} from "react-redux";

import {logout} from '../Action/UserAction'
export function Nav(){
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const logoutUser = () =>{
        dispatch(logout())
        navigate('/issue')
    }
    const isLoggedIn = useSelector(state=>state.UserReducer.isLoggedIn);
    return(

        <aside id="leftsidebar" className="sidebar left">
            <p className="header text-primary"></p>
            <div className="menu d-flex align-items-center">
            <ul className="nav navbar-right">
                    <li className="me-5 ms-auto"></li>
                    <li className="me-5 ms-auto"> 
                        {(!isLoggedIn) ? (<Link to="/users/login"> <i className=" " aria-hidden="true"><button className='btn btn-success'>SIGN IN</button></i></Link>) :
                        (<button className="btn btn-link" onClick={logoutUser}><i className=" " aria-hidden="true"><button className='btn btn-success'>SIGN OUT</button></i> </button>)}
                       <hr/>
                       </li>
                       {/* <Link to="/users/signup">
                        <i className="" aria-hidden="true"><button className='btn btn-info'>SIGN UP</button></i></Link>
                    <hr/> */}
                    <li className="me-5 ms-auto">
                    <Link to='/issue/create' style={{ display: 'flex',textDecoration:'none', flexDirection: 'row-reverse' }}>
            <button type="button" className="btn btn-warning">Add Issue</button></Link>
            </li>
            <li className="me-5 ms-auto">
            <hr/><Link to='/issue' style={{ display: 'flex', flexDirection: 'row-reverse' ,textDecoration:'none'}}>
                <button type="button" className="btn btn-primary">View Issues</button></Link>
                </li>
                    {/* <li className="ms-auto me-5">
                        <a href="javascript:void(0);"
                        className="js-right-sidebar"
                        data-close="true">
                            <i className="fa fa-cog fa-spin fa-2x fa-fw"></i>
                            <span className="sr-only">Loading...</span>
                        </a>
                    </li> */}
                    
                </ul>
            </div>
        </aside>
    )
}