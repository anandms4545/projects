import React from "react";
// import { Link,useNavigate} from "react-router-dom";
// import { useSelector ,useDispatch} from "react-redux";

// import {logout} from '../Action/UserAction'

export function Header(){
    // const navigate = useNavigate();
    // const dispatch = useDispatch();
    // const logoutUser = () =>{
    //     dispatch(logout())
    //     navigate('/issue')
    // }
    // const isLoggedIn = useSelector(state=>state.UserReducer.isLoggedIn);
    return(
        <div>
            <nav className="navbar fixed-top" 
            // style={{'background':'grey'}}
            >
                <a className="navbar-brand" href="#">
                    <img src="logo.png" width="40" height="40"  className="d-inline-block align-top" />
                    <span className="ml-2" style={{color: "red"}}
>BUGSPRO</span>
                </a>
                {/* <ul className="nav navbar-left">
                    <li className="hidden sm-down">
                        <div className="input-group">
                            <input type="text" 
                            className="form-control"
                            placeholder="Search...."/>
                        <i className="fa fa-search fa-2x ml-1 mx-auto"
                        aria-hidden="true"></i>
                        </div>
                    </li>
                    </ul>   */}
                    {/* <ul className="nav navbar-right">
                    <li className="me-5 ms-auto"></li>
                    <li className="me-5 ms-auto">
                        {(!isLoggedIn) ? (<Link to="/users/login"> <i className="fa fa-sign-in fa-2x ms-auto me-5" aria-hidden="true"></i></Link>) :
                        (<button className="btn btn-link" onClick={logoutUser}><i className="fa fa-sign-out fa-2x" aria-hidden="true"></i> </button>)}
                       <Link to="/users/signup">
                        <i className="fa fa-user-plus fa-2x ml-5" aria-hidden="true"></i></Link>
                    </li> */}
                    {/* <li className="ms-auto me-5">
                        <a href="javascript:void(0);"
                        className="js-right-sidebar"
                        data-close="true">
                            <i className="fa fa-cog fa-spin fa-2x fa-fw"></i>
                            <span className="sr-only">Loading...</span>
                        </a>
                    </li> */}
                {/* </ul> */}
            </nav>

        </div>
    )
}