import React from "react";

import { Header } from "./Header";
import { Nav } from "./Nav";
import './layout.css';
import { Article } from "./Article";

export const Layout = () => {
    return (
        <div>
            <header>
                <Header />
            </header>
            <div id="main">
                <nav>
                    <Nav/>
                </nav>
                <article>
                    <Article/>
                </article>
            </div>
            <div>
                <footer>

                </footer>
            </div> 
        </div> 
    )
}