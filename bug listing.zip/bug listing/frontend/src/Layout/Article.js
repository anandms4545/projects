import React from "react";
// import ProductRoutes from "../Routes/IssueRoutes";
import UserRoutes from "../Routes/UserRoutes";
export function Article(){

    return(
        <section id="rightsection" className="sidebar right" >
            {/* <ProductRoutes/> */}
            <UserRoutes/>
        </section>
    )
}