export const FETCH_ISSUES = "FETCH_ISSUES"
export const FETCH_ISSUES_SUCCESS = "FETCH_ISSUES_SUCCESS"
export const FETCH_ISSUES_FAILURE = "FETCH_ISSUES_FAILURE"

export const FETCH_ISSUE = "FETCH_ISSUE"
export const FETCH_ISSUE_SUCCESS = "FETCH_ISSUE_SUCCESS"
export const FETCH_ISSUE_FAILURE = "FETCH_ISSUE_FAILURE"

export const CREATE_ISSUE = "CREATE_ISSUE"
export const CREATE_ISSUE_SUCCESS = "CREATE_ISSUE_SUCCESS"
export const CREATE_ISSUE_FAILURE = "CREATE_ISSUE_FAILURE"

export const EDIT_ISSUE = "EDIT_ISSUE"
export const EDIT_ISSUE_SUCCESS = "EDIT_ISSUE_SUCCESS"
export const EDIT_ISSUE_FAILURE = "EDIT_ISSUE_FAILURE"

export const DELETE_ISSUE = "DELETE_ISSUE"
export const DELETE_ISSUE_SUCCESS = "DELETE_ISSUE_SUCCESS"
export const DELETE_ISSUE_FAILURE = "DELETE_ISSUE_FAILURE"

export const fetchIssues = () => {
    return {
        type: FETCH_ISSUES,
        
    }
}

export const fetchIssuesSuccess = data => ({type:FETCH_ISSUES_SUCCESS,data})

export const fetchIssuesFailure = () => ({type:FETCH_ISSUES_FAILURE});

export const fetchIssue = (id) =>{
    console.log("In Fetch Issue Action");
    console.log(id)
    return{
        type: FETCH_ISSUE,
        id
    }
}

export const fetchIssueSuccess = data =>({type: FETCH_ISSUE_SUCCESS,data})

export const fetchIssueFailure = () =>({type: FETCH_ISSUE_FAILURE})

export const createIssue = ({issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus})=>{
    return{
        type: CREATE_ISSUE,
        issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus
    };
}

export const createIssueSuccess = data =>({type:CREATE_ISSUE_SUCCESS,data})

export const createIssueFailure =() =>({type:CREATE_ISSUE_FAILURE})

export const editIssue = (id,issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus) =>{
    return{
        type:EDIT_ISSUE,
        payload:{
            id,
            issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus
        }
    }
}

export const editIssueSuccess = data => ({type:EDIT_ISSUE_SUCCESS,data})

export const editIssueFailure = () => ({type:EDIT_ISSUE_FAILURE})

export const deleteIssue = id =>{
    return{
        type:DELETE_ISSUE,
        id:id
    }
}

export const deleteIssueSuccess = data=>({type:DELETE_ISSUE_SUCCESS,data})

export const deleteIssueFailure = () =>({type:DELETE_ISSUE_FAILURE})