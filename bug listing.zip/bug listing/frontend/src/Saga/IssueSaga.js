import {call,put,takeLatest} from 'redux-saga/effects'

import {
    FETCH_ISSUES,fetchIssuesSuccess,fetchIssuesFailure,
    FETCH_ISSUE,fetchIssueSuccess,fetchIssueFailure,
    CREATE_ISSUE,createIssueSuccess,createIssueFailure,
    EDIT_ISSUE,editIssueSuccess,editIssueFailure,
    DELETE_ISSUE,deleteIssueSuccess,deleteIssueFailure, 
} from '../Action/IssueAction';

import api from './IssueApi'
function* getIssues(){
    try{
        const data = yield call(api.issues);
        yield put(fetchIssuesSuccess(data))
    }catch(error){
        console.log("Issues Fetch error")
        yield put(fetchIssuesFailure());
    }
}

function* getIssue(action){
    console.log("In get Issue");
    const {id} = action;
    try{
        const {data} = yield call(api.getissue,id)
        yield put(fetchIssueSuccess(data))
    }catch(err){
        console.log("Products fetch error")
        //onFailure(err)
        yield put(fetchIssueFailure())
    }
}

function* createIssue(action){
    console.log("Action create Issue is"+JSON.stringify(action))
    try{
        //const imgname=yield call (api.addImage,action.imagefilename)
        const {issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus} = action;
        let {data} = yield call(api.addissue,{issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus})
        console.log("Add Issue Saga is:" +JSON.stringify(data))
        yield put(createIssueSuccess(data))
    }catch(err){
        console.log("Error is "+JSON.stringify(err.response.data))
        yield put(createIssueFailure())
    }
}

function* editIssue(action){
    try{
        console.log("In saga Update Issue"+JSON.stringify(action))
        const{issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus}=action.payload;
        const id = action.payload.id
        console.log("Edit Issue Saga is"+" ID "+id+" issuenumber "+issuenumber+ " issuetitle "+issuetitle+" issudetails "+issuedetails+"issuecby"+issuecby+"priority"+priority+"issuestatus"+issuestatus)
        const data = yield call(api.editissue,id,issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus);
        console.log("Response in Update Issue ",data)
        yield put(editIssueSuccess(data))
    }catch(err){
        console.log(err)
        yield put(editIssueFailure(err));
    }
}

function* deleteIssue(action){
    try{
        console.log("Remove Issue saga "+JSON.stringify(action))
        const{id} = action;
        const data = yield call(api.deleteissue,id);
        console.log("Response is "+JSON.stringify(data))
        yield put(deleteIssueSuccess(data))
    }catch(err){
        yield put(deleteIssueFailure());
    }
}

export default function* IssueSaga(){
    yield takeLatest(FETCH_ISSUES,getIssues);
    yield takeLatest(FETCH_ISSUE,getIssue);
    yield takeLatest(CREATE_ISSUE,createIssue);
    yield takeLatest(EDIT_ISSUE,editIssue);
    yield takeLatest(DELETE_ISSUE,deleteIssue)
}