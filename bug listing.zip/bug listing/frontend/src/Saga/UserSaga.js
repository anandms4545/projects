
import {call,takeLatest} from "redux-saga/effects"
import {  REGISTER_USER,  USER_LOGIN,} from "../Action/UserAction"
import api from '../Saga/UserApi'
function* createUser(action){
    console.log("In User saga")
    const {onSuccess,onFailure}=action
    try{
        const {name,email,password} = action;
        let data = yield call(api.registeruser,{name,email,password})
        console.log("In user saga is",JSON.stringify(data))
        onSuccess(data)
      
    }
    catch(error){
        console.log("Error is "+JSON.stringify(error))
        onFailure(error) 
    }
}

function* getUser(action){
    console.log("In User Saga get user action is",action);
    const {onSuccess,onFailure}=action
    try{
        const {email,password}= action
        let data = yield call(api.getuser,{email,password})
        console.log("Usersaga success data",data);
        onSuccess(data)
    }
    catch(error){
        onFailure(error)
       
    }
}

export default function* UserSaga(){
    yield takeLatest(REGISTER_USER,createUser)
    yield takeLatest(USER_LOGIN,getUser)
}