import axios from 'axios'

const issues = async () =>{
    const {data} = await axios.get('http://localhost:5000/issue/getIssues');
    return data;
}

const getissue=async (id)=>await axios.get(`http://localhost:5000/issue/getIssue/${id}`);

const addissue = async (data)=>await axios.post('http://localhost:5000/issue/addIssue',data); 

const addImage = async imagefile =>{
    var formData =new FormData();
    formData.append('imagefile',imagefile);
    const options ={
        headers: {
            'Content-type':'multipart/form-data',
        }
    };
    let filename = await axios.post('http://localhost:5000/Multer/image',formData,options)
    return filename
}

const editissue = async (id,issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus)=>{
    console.log("In Edit issue API ID is: ",id)
    let {data}= await axios.put(`http://localhost:5000/issue/updateIssue/${id}`,{issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus})
    return data
}

const deleteissue = async id=>{
    console.log("Delete issue API ",id)
    let {data} = await axios.delete(`http://localhost:5000/issue/deleteIssue/${id}`);
    return data
}

export default {issues, getissue, addissue, addImage, editissue, deleteissue}