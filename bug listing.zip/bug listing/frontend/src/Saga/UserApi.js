import axios from 'axios'

const registeruser = async (data1) =>{
    console.log("In User API Data is ",JSON.stringify(data1));
    let{data}=await axios.post('http://localhost:5000/user/signup',data1)
    return data
}

const getuser = async (data1)=>{
    console.log("In User API Data is ",JSON.stringify(data1))
    let {data}=await axios.post('http://localhost:5000/user/login',data1)
    console.log("response in user Api is",data);
    return data
}
export default {registeruser,getuser}