import React from 'react';


import './App.css';
import Store from './Store/store'
import { Layout } from './Layout/layout';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom'

function App() {
  return (
    <div className="App">

      <Provider store={Store}>
        <Router>
          <Layout />
        </Router>
      </Provider>
    </div>
  );
}

export default App;
