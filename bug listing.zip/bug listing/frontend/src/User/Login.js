import React from "react"
import {useFormik} from 'formik'
import { useDispatch } from "react-redux"
import {  useState } from "react";
import jwt_decode from 'jwt-decode'
import validator from 'validator'
import { useNavigate } from "react-router-dom";
import {userLogin,userLoginFailure,userLoginSuccess} from "../Action/UserAction"

export default function Login(){
    const [emailError, setEmailError] = useState('')
    const validateEmail = (e) => {
        var email = e.target.value
      
        if (validator.isEmail(email)) {
          setEmailError('Valid Email :)')
        } else {
          setEmailError('Enter valid Email!')
        }
      }



    const dispatch = useDispatch();
    const navigate = useNavigate();
    const onSuccess = (data) => {
        console.log("Login successfully",data);
        dispatch(userLoginSuccess(data));
        var { role } = jwt_decode(localStorage.getItem("userToken"));
        alert("Logged in successfully")
        console.log("Role IN LOGIN is " + role);
        navigate('/issue');
    }
    const onFailure = (err) => {
        console.log("Error occured while login ",err);
      
        dispatch(userLoginFailure());
        alert("Error occured while Login");
    }
    const formik=useFormik({
        enableReinitialize:true,
        initialValues:{
            email:'',
            password:''
        },
        onSubmit:async({email,password})=>{
                dispatch(userLogin({email,password},onSuccess,onFailure));
                

            }
        }
    );


    return(
        <div className='h-50 w-50 ml-5 mt-5 mx-auto ' >
        <form onSubmit={formik.handleSubmit} className='d-block'>
            <h3>Log In</h3>
            <div className='form-group'>
                <label>Email</label>
                <input id="email"
                name="email"
                type="email"
                pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
                required

                onChange={formik.handleChange} 
                onInput={(e) => validateEmail(e)}
                value={formik.values.email}
                className="form-control"
                placeholder="Enter Email" /> <br/>
                 <span style={{
          fontWeight: 'bold',
          color: 'red',
        }}>{emailError}</span>
            </div>
            <div className='form-group'>
                <label>Password</label>
                <input id="password"
                name="password"
                type="password"
                onChange={formik.handleChange}
                value={formik.values.password}
                className="form-control"
                placeholder="Enter password"
                // pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                // title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
                //  required

                
                />
            </div>
            
            <button type='submit' className="btn btn-primary btn-lg btn-block">Log In </button>
        </form>
        
    </div>

    
    )
}