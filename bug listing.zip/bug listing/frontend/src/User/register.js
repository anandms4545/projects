import React from "react"
import {useFormik} from 'formik'
import { useDispatch } from "react-redux"
import { registerUser, registerUserSuccess,registerUserFailure} from "../Action/UserAction";
import { useNavigate } from "react-router-dom";
export function Register(){
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const onSuccess = (data) => {
        console.log("User registered successfully",data)
        alert("User is added");
        dispatch(registerUserSuccess(data))
        navigate('/users/login');
    }
    const onFailure = (err) => {
        console.log("Error occured while signup ",err)
        alert("Error occured while REgistration")
        dispatch(registerUserFailure())
    }
   
    const formik=useFormik({
        enableReinitialize:true,
        initialValues:{
            name:'',
            email:'',
            password:''
        },
        onSubmit:async({name,email,password})=>{
            
                dispatch(registerUser({name,email,password},onSuccess,onFailure))
                alert("User registered successfully")
                navigate('/products')

            }
        }
    );
    
    return(
        <div className='h-50 w-50 ml-5 mt-5 mx-auto  ' >
            <form onSubmit={formik.handleSubmit} className='d-block'>
                <h3>Sign Up</h3>
                <div className='form-group'>
                    <label>User Name</label>
                    <input id="name"
                    name="name"
                    type="text"
                    onChange={formik.handleChange}
                    value={formik.values.name}
                    className="form-control"
                    placeholder="Enter User Name"/>
                </div>
                <div className='form-group'>
                    <label>Email</label>
                    <input id="email"
                    name="email"
                    type="email"
                    onChange={formik.handleChange}
                    value={formik.values.email}
                    className="form-control"
                    placeholder="Enter Email"/>
                </div>
                <div className='form-group'>
                    <label>Password</label>
                    <input id="password"
                    name="password"
                    type="password"
                    onChange={formik.handleChange}
                    value={formik.values.password}
                    className="form-control"
                    placeholder="Enter password"/>
                </div>
                
                <button type='submit' className="btn btn-primary btn-lg btn-block">Sign Up</button>
            </form>
        </div>
    )
}