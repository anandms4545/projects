import React from "react";
import { useEffect, useState } from "react";
import {  fetchIssues } from "../Action/IssueAction";
import {useDispatch ,useSelector} from 'react-redux'
import { MDBDataTable } from 'mdbreact';


// import {Link} from 'react-router-dom'
import { IssueCard } from "./IssueCard";
export const IssueList=()=>{
  
    const [searchTerm,setsearchTerm]=useState("")

    const dispatch = useDispatch();
    const issues = useSelector(state=>state.IssueReducer.issues);

    // var arr2 = arr1.map(v => ({ user: v.user, liked: v.liked }));
    // var data = issues.map(v => ({ id: v._id, issuedate: v.issuedate, issuenumber:v.issuenumber }));
    let data = issues.map(obj => {
        let rObj = {}
        rObj[obj._id ] = obj.issuedate
        return rObj
     })
    //  let reformattedArray = kvArray.map(obj => {
    //     let rObj = {}
    //     rObj[obj.key] = obj.value
    //     return rObj
    //  })
    
    //  const data=issues.map((issues)=>
    //   key:{issues._id} id={issues._id} issuedate={issues.issuedate} issuenumber={issues.issuenumber} 
    //  issuetitle={issues.issuetitle} issuedetails={issues.issuedetails}
    //  issuecby={issues.issuecby} priority={issues.priority}
    //  issuestatus={issues.issuestatus}
   


    useEffect(()=>{

        dispatch(fetchIssues());
       
    },[]);
    return(
        <div>
            
            <MDBDataTable
      striped
      bordered
      small
      data={data}
    />
 





            {/* <Link to='/issue/create' style={{ display: 'flex', flexDirection: 'row-reverse' }}>
            <button type="button" className="btn btn-warning">Log Bug or Issue</button></Link> */}

            <input type="text" placeholder="Search ..." className="form-control"
            style={{marginTop:50, marginBottom:20, width:"40%"}}
            onChange={(e) =>{
                setsearchTerm(e.target.value);
            }}

            />



            <h1>Issue List</h1>
            
            <table className="table table-dark table-hover table-borderless  table-sm ">
                <tbody>
                    <tr className=" table-primary" >

                    <th>Issue ID</th>
                    <th>Issue Number</th>
                    <th>Issue Date</th>
                    <th>Issue Title</th>
                    <th>Issue Details</th>
                    <th>Issued Created By</th>
                    <th>Priority</th>
                    <th>Issue Status</th>
                    <th>Edit Issue</th>
                    <th>Delete Issue</th>
                    </tr> 
                    
            
            {issues.length>0 ? issues.filter((val) => {
                if(searchTerm === "") {
                    return val;
                } 
                
                else if(
                    val.issuecby.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    val.issuestatus.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    val.priority.toLowerCase().includes(searchTerm.toLowerCase())  ||
                    val.issuenumber.toString().includes(searchTerm) ||
                    val.issuedate.includes(searchTerm)  ||
                    val.issuedetails.toLowerCase().includes(searchTerm.toLowerCase())  ||
                    val.issuetitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    val._id.toString().includes(searchTerm)
                ){
                    return val;
                }
            }).map((issues)=>
                <IssueCard key={issues._id} id={issues._id} issuedate={issues.issuedate} issuenumber={issues.issuenumber} 
                issuetitle={issues.issuetitle} issuedetails={issues.issuedetails}
                issuecby={issues.issuecby} priority={issues.priority}
                issuestatus={issues.issuestatus}
                />)
                :<tr><td> Issues is being fetched</td></tr>}
            </tbody>
            </table>
            
        </div>
    )
}




















// import React from "react";
// import { useEffect, useState } from "react";
// import {  fetchIssues } from "../Action/IssueAction";
// import {useDispatch ,useSelector} from 'react-redux'
// // import { MDBDataTable } from 'mdbreact';

// // import {Link} from 'react-router-dom'
// import { IssueCard } from "./IssueCard";
// export const IssueList=()=>{
  
//     const [searchTerm,setsearchTerm]=useState("")

//     const dispatch = useDispatch();
//     const issues = useSelector(state=>state.IssueReducer.issues);

//     const data = Object.entries(issues);
//     console.log(data);
//     //  const data=issues.map((issues)=>
//     //   key:{issues._id} id={issues._id} issuedate={issues.issuedate} issuenumber={issues.issuenumber} 
//     //  issuetitle={issues.issuetitle} issuedetails={issues.issuedetails}
//     //  issuecby={issues.issuecby} priority={issues.priority}
//     //  issuestatus={issues.issuestatus}
   


//     useEffect(()=>{

//         dispatch(fetchIssues());
       
//     },[]);
//     return(
//         <div>
            
//             {/* <MDBDataTable
//       striped
//       bordered
//       small
//       data={data}
//     />
//   */}





//             {/* <Link to='/issue/create' style={{ display: 'flex', flexDirection: 'row-reverse' }}>
//             <button type="button" className="btn btn-warning">Log Bug or Issue</button></Link> */}

//             <input type="text" placeholder="Search ..." className="form-control"
//             style={{marginTop:50, marginBottom:20, width:"40%"}}
//             onChange={(e) =>{
//                 setsearchTerm(e.target.value);
//             }}

//             />



//             <h1>Issue List</h1>
//             <table className="table bg-info  table-bordered table-striped ">
//                 <tbody>
//                     <tr className="shadow" style={{backgroundColor: "lightblue"}}
// >
//                     <th>Issue ID</th>
//                     <th>Issue Number</th>
//                     <th>Issue Date</th>
//                     <th>Issue Title</th>
//                     <th>Issue Details</th>
//                     <th>Issued Created By</th>
//                     <th>Priority</th>
//                     <th>Issue Status</th>
//                     <th>Edit Issue</th>
//                     <th>Delete Issue</th>
//                     </tr> 
                    
            
//             {issues.length>0 ? issues.filter((val) => {
//                 if(searchTerm === "") {
//                     return val;
//                 } 
                
//                 else if(
//                     val.issuecby.toLowerCase().includes(searchTerm.toLowerCase()) ||
//                     val.issuestatus.toLowerCase().includes(searchTerm.toLowerCase()) ||
//                     val.priority.toLowerCase().includes(searchTerm.toLowerCase())  ||
//                     val.issuenumber.toString().includes(searchTerm) ||
//                     val.issuedate.includes(searchTerm)  ||
//                     val.issuedetails.toLowerCase().includes(searchTerm.toLowerCase())  ||
//                     val.issuetitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
//                     val._id.toString().includes(searchTerm)
//                 ){
//                     return val;
//                 }
//             }).map((issues)=>
//                 <IssueCard key={issues._id} id={issues._id} issuedate={issues.issuedate} issuenumber={issues.issuenumber} 
//                 issuetitle={issues.issuetitle} issuedetails={issues.issuedetails}
//                 issuecby={issues.issuecby} priority={issues.priority}
//                 issuestatus={issues.issuestatus}
//                 />):<tr><td> Issues is being fetched</td></tr>}
//             </tbody>
//             </table>
            
//         </div>
//     )
// }
