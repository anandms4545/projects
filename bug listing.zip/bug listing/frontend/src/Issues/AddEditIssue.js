import React from 'react';
import {useFormik} from 'formik';

import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
//import { ProductReducer } from '../Reducer/ProductReducer';
import { createIssue, fetchIssue,editIssue,createIssueFailure,createIssueSuccess } from '../Action/IssueAction';
import { useEffect } from 'react';
export const AddEditIssue =()=>{
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const params = useParams();
    
    
    const onSuccess = (data) => {
        console.log("Data created is: ",data)
        alert("Issue is added");
        dispatch(createIssueSuccess(data))
        navigate('/issues')
    }
    const onFailure = (err) => {
        console.log("Error occured while adding ",err)
        alert("Error occured while Issue addition")
       dispatch(createIssueFailure())
    }
    let issue = useSelector(state =>{
        return state.IssueReducer.issue
    })
    
    useEffect(()=>{
    // let image = params.id === undefined ? false :true
    // console.log("Image value is:",image);
    if(params.id === undefined)
        issue = {}
    else   
        dispatch(fetchIssue(params.id))
    },[])
    

        
    const formik=useFormik({
        enableReinitialize:true,
        initialValues:{
            // issuenumber:issue.issuenumber ||'',
            issuedate:issue.issuedate ||'',
            issuetitle:issue.issuetitle ||'',
            issuedetails:issue.issuedetails||'',
            issuecby:issue.issuecby||'',
            priority:issue.priority||'',
            issuestatus:issue.issuestatus||''
        },
    
        onSubmit:async({issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus})=>{
            if(params.id === undefined){
                dispatch(createIssue({issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus},onSuccess,onFailure))
                alert("Record is added") 
                navigate('/issue')
            }else {
                let id = params.id
                dispatch(editIssue(id,issuenumber,issuetitle,issuedetails,issuecby,priority,issuestatus));
                alert("Record is updated")
                navigate('/issue')
            }
        }
    });
    return(
        <div className='h-50 w-50 ml-5 mt-5 mx-auto'>
            <form onSubmit={formik.handleSubmit} className='d-block'>
                <h3>Add Issue</h3>
              
                {/* <div className='form-group'>
                    <label>ISSUE NUMBER</label>
                    <input id="issuenumber"
                    name="issuenumber"
                    type="number"
                    onChange={formik.handleChange}
                    value={formik.values.issuenumber}
                    className="form-control"
                    placeholder="Enter issuenumber"/>
                </div> */}
                <div className='form-group'>
                    <label>ISSUE TITLE</label>
                    <input id="issuetitle"
                    name="issuetitle"
                    type="text"
                    onChange={formik.handleChange}
                    value={formik.values.issuetitle}
                    className="form-control"
                    placeholder="Enter issuetitle"/>
                </div>
                <div className='form-group'>
                    <label>ISSUE DETAILS</label>
                    <input id="issuedetails"
                    name="issuedetails"
                    type="text"
                    onChange={formik.handleChange}
                    value={formik.values.issuedetails}
                    className="form-control"
                    placeholder="Enter issuedetails"/>
                </div>
                <br/>
                <div className='form-group'>
                    <label>ISSUE CREATED BY</label>
                    <textarea id="issuecby"
                    name="issuecby"
                    onChange={formik.handleChange}
                    value={formik.values.issuecby}
                    className="form-control"
                    placeholder="issuecby"></textarea>
                </div>
                <br/>
           
                
                <div className='form-group'>
                <label> SELECT A PRIORITY</label><br/>
                    <select
                        name="priority"
                        value={formik.values.priority}
                        onChange={formik.handleChange}>
                            
                        <option value="" label="Select a Priority" />
                        <option value="low" label="low" />
                        <option value="Medium" label="Medium" />
                        <option value="high" label="High" />
                        
                    </select>
                </div>
                <br/>
                <div className='form-group'>
                <label>SELECT A STATUS</label><br/>
                    <select
                        name="issuestatus"
                        value={formik.values.issuestatus}
                        onChange={formik.handleChange}>
                        <option value="" label="Select a status" />
                        <option value="open" label="open" />
                        <option value="inprogress" label="inprogress" />
                        <option value="resolved" label="resolved" />
                        <option value="closed" label="closed" />
                        
                    </select>
                </div>
                <br/>

                <button type='submit' className="btn btn-primary btn-lg btn-block">ADD or EDIT </button>
            </form>
        </div>
    )
}


