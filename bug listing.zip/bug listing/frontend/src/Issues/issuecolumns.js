export const UserColumn = [
    {
        Header : "Issue Number",
        accessor: "issuenumber"
    },
    {
        Header : "Issue date",
        accessor: "issuedate"
    },
    {
        Header : "Issue Title",
        accessor: "issuetitle"
    },
    {
        Header : "Issue Details",
        accessor: "issuedetails"
    },
    {
        Header : "Issue Created By",
        accessor: "issuecby"
    },
    {
        Header : "Issue priority",
        accessor: "priority"
    },
    {
        Header : "Issue Status",
        accessor: "issuestatus"
    },
   
]