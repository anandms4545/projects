import React from 'react'
import { Link, useNavigate } from "react-router-dom"
import { useDispatch } from "react-redux";
import { deleteIssue } from "../Action/IssueAction";
// import { useEffect } from 'react';
export const IssueCard=({id,issuenumber,issuedate,issuetitle,issuedetails,issuecby,priority,issuestatus})=>{
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const deleteIssues =(id)=>{
        if(confirm("Are you sure you want to delete?")){

        dispatch(deleteIssue(id));
        
    }else{
        navigate('/issue'); 
    }
        return;
}

    
    return(
        <>
        
            <tr>
                <td>{id}</td>
                <td>{issuenumber}</td>
                <td>{issuedate}</td>
                <td>{issuetitle}</td>
                <td>{issuedetails}</td>
                <td>{issuecby}</td>
                <td>{priority}</td>
                <td>{issuestatus}</td>
                <td><Link to={`/issue/update/${id}`} ><button className='btn btn-warning'>Edit</button> </Link></td>
                {/* <td><Link to={`/issue/delete/${id}`}>Delete Product</Link></td> */}
                <td><button onClick={deleteIssues} className='btn btn-danger'>Delete </button></td>
                </tr>
                
            </>
    )
}