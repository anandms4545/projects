// import React from "react";
// import {  Routes, Route, Navigate } from "react-router-dom";
// import {IssueList} from "../Issues/IssueList";
// // import { ProductDetails } from "../Product/ProductDetails";
// import { AddCart } from "../Cart/AddCart";
// import Login from "../User/Login";
// import CartDetails from '../Cart/CartDetails'
// import { useSelector } from "react-redux";
// export default function ProductRoutes(){
//     const userId =useSelector(state=>state.UserReducer.id)
//     const isLoggedIn = useSelector(state=>state.UserReducer.isLoggedIn);
//     return(
        
//             <Routes>
//             <Route path='/cart/add/:id'
//                 element={isLoggedIn ? <AddCart /> : <Login />} /> 
//                 <Route path="/cart/:id" element={<CartDetails userId={userId} />} />
//                 <Route path="/products" element={<IssueList/>}/>
//                 <Route path="/" element={<Navigate replace to="/products"/>}/>
//                 <Route path="/productDetails/:id" element={<ProductDetails/>}/>
//             </Routes>
        
//     )
// }