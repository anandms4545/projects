import React from "react";
import { Register } from "../User/register";
import {  Routes, Route} from "react-router-dom";
import {IssueList} from '../Issues/IssueList'
import { AddEditIssue} from '../Issues/AddEditIssue'
import Login from "../User/Login";
import { useSelector } from "react-redux";


export default function UserRoutes(){
    const isLoggedIn = useSelector(state=>state.UserReducer.isLoggedIn);


    return(
       
            <Routes>
                {/* <Route path="/issue" element={<IssueList/>}/> */}
                <Route path="/issue/create" element={isLoggedIn ?<AddEditIssue/> : <Login/>}/>
                <Route path="/issue/update/:id" element={<AddEditIssue/>}/>
                <Route path="/users/signup" element={<Register/>}/>
                <Route path="/users/login" element={<Login/>}/>
                <Route path='/issue'
                element={isLoggedIn ? <IssueList/> : <Login />} />
                
                
                 <Route path="/login" element={<Login/>}/>

            </Routes>
        
    )
}
