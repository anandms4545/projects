import {createStore,applyMiddleware,compose,combineReducers} from "redux"
import { IssueReducer } from "../Reducer/IssueReducer"
import createSagaMiddleware from "@redux-saga/core"
import IssueSaga from "../Saga/IssueSaga"
import UserSaga from "../Saga/UserSaga"
import { UserReducer } from "../Reducer/UserReducer"



const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__  || compose;
const sagaMiddleware = createSagaMiddleware();
const rootReducer = combineReducers({
    IssueReducer,UserReducer
})

const store = createStore(rootReducer,composeEnhancers(applyMiddleware(sagaMiddleware)))
sagaMiddleware.run(IssueSaga)
sagaMiddleware.run(UserSaga)

export default store;