let initState = {issues:[], issue:{}, loading:true,success:false}

export const IssueReducer = (state=initState,action)=>{
    console.log("In issue Reducer:",JSON.stringify(action))
    //console.log("Action type is ",action.type,JSON.stringify(action))
    switch (action.type){
        case 'FETCH_ISSUES':
        case 'DELETE_ISSUE':
        case 'EDIT_ISSUE':
        case 'FETCH_ISSUE':
        case 'CREATE_ISSUE':
            console.log("In Create Reducer: ",action)
            return{
                ...state,
                loading:true,
            }
        case "FETCH_ISSUES_SUCCESS":
            return{
                ...state,
                issues:action.data.issue,
                loading: false
            }
        case "FETCH_ISSUE_SUCCESS":
        console.log("Action data is: ",JSON.stringify(action))
            return{
                ...state,
                issue:action.data.issue,
                loading: false
            }
        case 'CREATE_ISSUE_SUCCESS':
        console.log("Create Product Success Action in Reducer")
            return{
                ...state,
                issues:action.data.issue ? state.issues.concat(action.data.issue) :state.issues,
                //product:action.data.product
                loading:false,
                success:action.data.success
            }
        case 'EDIT_ISSUE_SUCCESS':
        console.log("In edit process success data is:",action.data.issue)
            return{
                ...state,
                issues:{...state.issues,...action.data.issue},
                //product{},
                loading:false
            }
        case 'DELETE_ISSUE_SUCCESS':
            return{
                ...state,
                issues: state.issues.filter(issue => issue._id !== action.data.id),
                //product: action.data.product,
                loading:false
            }
        case 'FETCH_ISSUES_FAILURE':
        case 'FETCH_ISSUE_FAILURE':
        case 'CREATE_ISSUE_FAILURE':
        case 'EDIT_ISSUE_FAILURE':
        case 'DELETE_ISSUE_FAILURE':
            return {
                ...state,
                loading: false,
                success: false,
            }
        default:
            return state
    }
}